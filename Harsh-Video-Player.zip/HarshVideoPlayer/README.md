# Harsh Video Player

A small, video-only player for Android TV, made for low-RAM TVs (around 1 GB).

- Lists the videos found on the TV or a USB drive
- Plays them with AndroidX Media3 (ExoPlayer) using hardware decoding
- Audio and subtitle track selection from the player's settings button
- Works with a TV remote (D-pad), no touch screen needed
- Also opens videos from a file manager ("Open with")

## Build

1. Open this folder in Android Studio (JDK 17) and let Gradle sync.
2. Run on an Android TV device or emulator.
3. For a TV without Play Store: Build > Build APK(s), copy the APK to a pendrive and install it from the TV's file manager (allow unknown sources).

## Credits

Built with AndroidX Media3 (Apache License 2.0). Not affiliated with VideoLAN or VLC.
