package com.harsh.videoplayer

import android.os.Bundle
import android.widget.Toast
import androidx.annotation.OptIn
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView

@OptIn(UnstableApi::class)
class PlayerActivity : AppCompatActivity() {

    private var player: ExoPlayer? = null
    private lateinit var playerView: PlayerView
    private var resumePosition = 0L
    private var playWhenReady = true

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_player)
        playerView = findViewById(R.id.player_view)
    }

    override fun onStart() {
        super.onStart()
        startPlayer()
    }

    override fun onStop() {
        releasePlayer()
        super.onStop()
    }

    private fun startPlayer() {
        val uri = intent.data
        if (uri == null) {
            finish()
            return
        }

        // Small buffers so a 1 GB TV does not run out of RAM.
        val loadControl = DefaultLoadControl.Builder()
            .setBufferDurationsMs(15_000, 30_000, 1_500, 3_000)
            .setTargetBufferBytes(24 * 1024 * 1024)
            .setPrioritizeTimeOverSizeThresholds(false)
            .build()

        // Hardware decoders are used by default. Fallback helps on weak TV chips.
        val renderers = DefaultRenderersFactory(this).setEnableDecoderFallback(true)

        val exo = ExoPlayer.Builder(this, renderers)
            .setLoadControl(loadControl)
            .build()

        exo.addListener(object : Player.Listener {
            override fun onPlayerError(error: PlaybackException) {
                Toast.makeText(
                    this@PlayerActivity,
                    getString(R.string.play_error),
                    Toast.LENGTH_LONG
                ).show()
                finish()
            }
        })

        playerView.player = exo
        exo.setMediaItem(MediaItem.fromUri(uri))
        exo.seekTo(resumePosition)
        exo.playWhenReady = playWhenReady
        exo.prepare()
        player = exo
    }

    private fun releasePlayer() {
        player?.let {
            resumePosition = it.currentPosition
            playWhenReady = it.playWhenReady
            it.release()
        }
        player = null
        playerView.player = null
    }
}
