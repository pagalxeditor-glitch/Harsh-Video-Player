# Media3 ships its own consumer rules. Nothing extra needed.
