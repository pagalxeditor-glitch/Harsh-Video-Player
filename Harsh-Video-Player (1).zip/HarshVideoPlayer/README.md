# Harsh Video Player

A small, video-only player for Android TV, built on **VLC's playback engine (libVLC)**.
Made for low-RAM TVs (around 1 GB): no music library, no streaming, no extras, only video.

- Lists the videos found on the TV or a USB drive
- Plays almost any video/audio format through libVLC, with the TV's hardware decoder when possible
- Audio track and subtitle selection
- Works with a TV remote (D-pad): OK = play/pause, left/right = seek 10 s, up/down = show controls
- Also opens videos from a file manager ("Open with")

## Build

1. Open this folder in Android Studio (JDK 17) and let Gradle sync.
2. Run on an Android TV device or emulator.
3. For a TV without Play Store: Build > Build APK(s), copy the APK to a pendrive and install it from the TV's file manager (allow unknown sources).

## Download APK

Every push to `main` builds an APK with GitHub Actions: open the **Actions** tab, pick the latest run and download `Harsh-Video-Player-apk`.
Push a tag like `v1.0` and the APK is also attached to a GitHub Release.

## Credits and license notice

This app uses **libVLC** by [VideoLAN](https://www.videolan.org/), licensed under the GNU LGPL v2.1, as an unmodified library (`org.videolan.android:libvlc-all`).
"VLC" and the VLC cone are trademarks of VideoLAN. This project is not affiliated with or endorsed by VideoLAN.
