package com.harsh.videoplayer

import android.net.Uri

data class VideoItem(
    val id: Long,
    val title: String,
    val durationMs: Long,
    val sizeBytes: Long,
    val uri: Uri
)
