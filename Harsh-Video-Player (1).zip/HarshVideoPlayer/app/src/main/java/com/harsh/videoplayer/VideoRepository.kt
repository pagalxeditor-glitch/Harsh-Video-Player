package com.harsh.videoplayer

import android.content.ContentUris
import android.content.Context
import android.os.Build
import android.provider.MediaStore

object VideoRepository {

    fun load(context: Context): List<VideoItem> {
        val result = ArrayList<VideoItem>()

        val collection = if (Build.VERSION.SDK_INT >= 29) {
            MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
        } else {
            MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        }

        val projection = arrayOf(
            MediaStore.Video.Media._ID,
            MediaStore.Video.Media.DISPLAY_NAME,
            MediaStore.Video.Media.DURATION,
            MediaStore.Video.Media.SIZE
        )

        val cursor = context.contentResolver.query(
            collection,
            projection,
            null,
            null,
            MediaStore.Video.Media.DATE_ADDED + " DESC"
        )

        cursor?.use { c ->
            val idCol = c.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
            val nameCol = c.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME)
            val durCol = c.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION)
            val sizeCol = c.getColumnIndexOrThrow(MediaStore.Video.Media.SIZE)
            while (c.moveToNext()) {
                val id = c.getLong(idCol)
                result.add(
                    VideoItem(
                        id = id,
                        title = c.getString(nameCol) ?: "Video",
                        durationMs = c.getLong(durCol),
                        sizeBytes = c.getLong(sizeCol),
                        uri = ContentUris.withAppendedId(collection, id)
                    )
                )
            }
        }
        return result
    }
}
