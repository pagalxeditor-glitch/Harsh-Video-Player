package com.harsh.videoplayer

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {

    private lateinit var list: RecyclerView
    private lateinit var message: TextView
    private val adapter = VideoAdapter { item -> openPlayer(item) }
    private val executor = Executors.newSingleThreadExecutor()

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) loadVideos() else showMessage(getString(R.string.permission_needed))
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        list = findViewById(R.id.video_list)
        message = findViewById(R.id.message)
        list.layoutManager = LinearLayoutManager(this)
        list.adapter = adapter

        if (!hasPermission()) {
            permissionLauncher.launch(storagePermission())
        }
    }

    override fun onStart() {
        super.onStart()
        if (hasPermission()) loadVideos()
    }

    override fun onDestroy() {
        executor.shutdown()
        super.onDestroy()
    }

    private fun loadVideos() {
        executor.execute {
            val videos = VideoRepository.load(applicationContext)
            runOnUiThread {
                if (isDestroyed) return@runOnUiThread
                adapter.submit(videos)
                if (videos.isEmpty()) {
                    showMessage(getString(R.string.no_videos))
                } else {
                    message.visibility = View.GONE
                    list.visibility = View.VISIBLE
                    if (!list.hasFocus()) {
                        list.post { list.layoutManager?.findViewByPosition(0)?.requestFocus() }
                    }
                }
            }
        }
    }

    private fun showMessage(text: String) {
        message.text = text
        message.visibility = View.VISIBLE
        list.visibility = View.GONE
    }

    private fun openPlayer(item: VideoItem) {
        startActivity(Intent(this, PlayerActivity::class.java).setData(item.uri))
    }

    private fun storagePermission(): String =
        if (Build.VERSION.SDK_INT >= 33) {
            Manifest.permission.READ_MEDIA_VIDEO
        } else {
            Manifest.permission.READ_EXTERNAL_STORAGE
        }

    private fun hasPermission(): Boolean =
        ContextCompat.checkSelfPermission(this, storagePermission()) ==
            PackageManager.PERMISSION_GRANTED
}
