package com.harsh.videoplayer

import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.os.SystemClock
import android.provider.OpenableColumns
import android.view.KeyEvent
import android.view.View
import android.widget.Button
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import org.videolan.libvlc.LibVLC
import org.videolan.libvlc.Media
import org.videolan.libvlc.MediaPlayer
import org.videolan.libvlc.util.VLCVideoLayout

class PlayerActivity : AppCompatActivity() {

    private lateinit var videoLayout: VLCVideoLayout
    private lateinit var controls: View
    private lateinit var titleView: TextView
    private lateinit var timeCurrent: TextView
    private lateinit var timeTotal: TextView
    private lateinit var seek: SeekBar
    private lateinit var btnPlayPause: Button
    private lateinit var btnAudio: Button
    private lateinit var btnSubtitles: Button

    private var libVlc: LibVLC? = null
    private var player: MediaPlayer? = null
    private var fileDescriptor: ParcelFileDescriptor? = null

    private var resumePosition = 0L
    private var pendingSeek = 0L
    private var lastUserSeek = 0L

    private val handler = Handler(Looper.getMainLooper())
    private val hideRunnable = Runnable {
        // Keep the controls on screen while paused.
        if (player?.isPlaying == true) controls.visibility = View.GONE
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_player)

        videoLayout = findViewById(R.id.video_layout)
        controls = findViewById(R.id.controls)
        titleView = findViewById(R.id.player_title)
        timeCurrent = findViewById(R.id.time_current)
        timeTotal = findViewById(R.id.time_total)
        seek = findViewById(R.id.seek)
        btnPlayPause = findViewById(R.id.btn_play_pause)
        btnAudio = findViewById(R.id.btn_audio)
        btnSubtitles = findViewById(R.id.btn_subtitles)

        titleView.text = intent.data?.let { displayName(it) } ?: ""

        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(bar: SeekBar, progress: Int, fromUser: Boolean) {
                if (fromUser) {
                    lastUserSeek = SystemClock.uptimeMillis()
                    player?.setTime(progress.toLong())
                    timeCurrent.text = formatDuration(progress.toLong())
                }
            }

            override fun onStartTrackingTouch(bar: SeekBar) {}
            override fun onStopTrackingTouch(bar: SeekBar) {}
        })

        btnPlayPause.setOnClickListener { togglePlayPause() }
        btnAudio.setOnClickListener { showAudioTracks() }
        btnSubtitles.setOnClickListener { showSubtitleTracks() }
    }

    override fun onStart() {
        super.onStart()
        startPlayer()
    }

    override fun onStop() {
        releasePlayer()
        super.onStop()
    }

    // ---------------------------------------------------------------- player

    private fun startPlayer() {
        val uri = intent.data
        if (uri == null) {
            finish()
            return
        }

        val vlc = LibVLC(this, ArrayList<String>())
        val mp = MediaPlayer(vlc)
        libVlc = vlc
        player = mp

        // true = show subtitles, false = SurfaceView (lighter than TextureView)
        mp.attachViews(videoLayout, null, true, false)

        mp.setEventListener { event ->
            val type = event.type
            val time = event.timeChanged
            val length = event.lengthChanged
            runOnUiThread { handleEvent(type, time, length) }
        }

        val media = openMedia(vlc, uri)
        if (media == null) {
            Toast.makeText(this, R.string.play_error, Toast.LENGTH_LONG).show()
            releasePlayer()
            finish()
            return
        }

        // Use the TV's hardware decoder when it can, fall back to software otherwise.
        media.setHWDecoderEnabled(true, false)
        mp.setMedia(media)
        media.release()

        pendingSeek = resumePosition
        resumePosition = 0L
        mp.play()
        showControls()
    }

    private fun releasePlayer() {
        handler.removeCallbacks(hideRunnable)
        val mp = player
        if (mp != null) {
            resumePosition = mp.time
            mp.setEventListener(null)
            mp.stop()
            mp.detachViews()
            mp.release()
        }
        libVlc?.release()
        player = null
        libVlc = null
        try {
            fileDescriptor?.close()
        } catch (_: Exception) {
        }
        fileDescriptor = null
    }

    private fun openMedia(vlc: LibVLC, uri: Uri): Media? {
        return try {
            val pfd = contentResolver.openFileDescriptor(uri, "r")
            if (pfd != null) {
                fileDescriptor = pfd
                Media(vlc, pfd.fileDescriptor)
            } else {
                Media(vlc, uri)
            }
        } catch (e: Exception) {
            try {
                Media(vlc, uri)
            } catch (e2: Exception) {
                null
            }
        }
    }

    private fun handleEvent(type: Int, time: Long, length: Long) {
        when (type) {
            MediaPlayer.Event.Playing -> {
                if (pendingSeek > 0) {
                    player?.setTime(pendingSeek)
                    pendingSeek = 0L
                }
                updatePlayButton()
            }
            MediaPlayer.Event.Paused -> {
                updatePlayButton()
                showControls()
            }
            MediaPlayer.Event.TimeChanged -> updateProgress(time)
            MediaPlayer.Event.LengthChanged -> {
                seek.max = length.toInt()
                seek.keyProgressIncrement = 10_000 // 10 seconds per D-pad press
                timeTotal.text = formatDuration(length)
            }
            MediaPlayer.Event.EndReached -> finish()
            MediaPlayer.Event.EncounteredError -> {
                Toast.makeText(this, R.string.play_error, Toast.LENGTH_LONG).show()
                finish()
            }
        }
    }

    // -------------------------------------------------------------- controls

    private fun togglePlayPause() {
        val mp = player ?: return
        if (mp.isPlaying) mp.pause() else mp.play()
        updatePlayButton()
        scheduleHide()
    }

    private fun updatePlayButton() {
        val playing = player?.isPlaying == true
        btnPlayPause.setText(if (playing) R.string.pause else R.string.play)
    }

    private fun updateProgress(time: Long) {
        // Ignore the player's old position for a moment after the user seeks.
        if (SystemClock.uptimeMillis() - lastUserSeek < 800) return
        setProgressUi(time)
    }

    private fun setProgressUi(time: Long) {
        seek.progress = time.coerceAtLeast(0L).toInt()
        timeCurrent.text = formatDuration(time)
    }

    private fun seekBy(deltaMs: Long) {
        val mp = player ?: return
        val length = mp.length
        if (length <= 0) return
        val target = (mp.time + deltaMs).coerceIn(0L, length - 1000L)
        mp.setTime(target)
        lastUserSeek = SystemClock.uptimeMillis()
        setProgressUi(target)
    }

    private fun showControls() {
        val wasHidden = controls.visibility != View.VISIBLE
        controls.visibility = View.VISIBLE
        updatePlayButton()
        if (wasHidden) btnPlayPause.requestFocus()
        scheduleHide()
    }

    private fun hideControls() {
        handler.removeCallbacks(hideRunnable)
        controls.visibility = View.GONE
    }

    private fun scheduleHide() {
        handler.removeCallbacks(hideRunnable)
        handler.postDelayed(hideRunnable, 5000)
    }

    private fun showAudioTracks() {
        val mp = player ?: return
        showTrackDialog(getString(R.string.audio), mp.audioTracks, mp.audioTrack) { id ->
            mp.setAudioTrack(id)
        }
    }

    private fun showSubtitleTracks() {
        val mp = player ?: return
        showTrackDialog(getString(R.string.subtitles), mp.spuTracks, mp.spuTrack) { id ->
            mp.setSpuTrack(id)
        }
    }

    private fun showTrackDialog(
        title: String,
        tracks: Array<MediaPlayer.TrackDescription>?,
        currentId: Int,
        onPick: (Int) -> Unit
    ) {
        if (tracks == null || tracks.isEmpty()) {
            Toast.makeText(this, R.string.no_tracks, Toast.LENGTH_SHORT).show()
            return
        }
        val names = tracks.map { it.name ?: "Track ${it.id}" }.toTypedArray()
        val checked = tracks.indexOfFirst { it.id == currentId }
        handler.removeCallbacks(hideRunnable)
        AlertDialog.Builder(this)
            .setTitle(title)
            .setSingleChoiceItems(names, checked) { dialog, which ->
                onPick(tracks[which].id)
                dialog.dismiss()
            }
            .setOnDismissListener { scheduleHide() }
            .show()
    }

    private fun displayName(uri: Uri): String {
        try {
            contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
                ?.use { c ->
                    if (c.moveToFirst()) {
                        val name = c.getString(0)
                        if (!name.isNullOrEmpty()) return name
                    }
                }
        } catch (_: Exception) {
        }
        return uri.lastPathSegment ?: ""
    }

    // ------------------------------------------------------------ remote keys

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (event.action != KeyEvent.ACTION_DOWN) return super.dispatchKeyEvent(event)

        val visible = controls.visibility == View.VISIBLE

        when (event.keyCode) {
            KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE,
            KeyEvent.KEYCODE_MEDIA_PLAY,
            KeyEvent.KEYCODE_MEDIA_PAUSE -> {
                togglePlayPause()
                showControls()
                return true
            }
            KeyEvent.KEYCODE_MEDIA_FAST_FORWARD -> {
                seekBy(10_000)
                showControls()
                return true
            }
            KeyEvent.KEYCODE_MEDIA_REWIND -> {
                seekBy(-10_000)
                showControls()
                return true
            }
            KeyEvent.KEYCODE_BACK -> if (visible && player?.isPlaying == true) {
                hideControls()
                return true
            }
        }

        if (!visible) {
            when (event.keyCode) {
                KeyEvent.KEYCODE_DPAD_CENTER,
                KeyEvent.KEYCODE_ENTER,
                KeyEvent.KEYCODE_NUMPAD_ENTER -> {
                    togglePlayPause()
                    showControls()
                    return true
                }
                KeyEvent.KEYCODE_DPAD_LEFT -> {
                    seekBy(-10_000)
                    showControls()
                    return true
                }
                KeyEvent.KEYCODE_DPAD_RIGHT -> {
                    seekBy(10_000)
                    showControls()
                    return true
                }
                KeyEvent.KEYCODE_DPAD_UP,
                KeyEvent.KEYCODE_DPAD_DOWN -> {
                    showControls()
                    return true
                }
            }
        } else {
            scheduleHide()
        }
        return super.dispatchKeyEvent(event)
    }
}
