# libVLC is called from native code by class/method name, so it must not be renamed or removed.
-keep class org.videolan.libvlc.** { *; }
-dontwarn org.videolan.**
